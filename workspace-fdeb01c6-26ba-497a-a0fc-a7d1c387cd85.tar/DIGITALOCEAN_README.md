# DigitalOcean Manager

Aplicativo completo para gerenciar Droplets da DigitalOcean usando a API oficial.

## Funcionalidades

### Gerenciamento de Droplets
- ✅ Listar todos os Droplets da sua conta
- ✅ Criar novos Droplets com configuração completa
  - Seleção de região (datacenter)
  - Seleção de tamanho (vCPUs, RAM, disco)
  - Seleção de imagem (Sistema Operacional)
  - Configuração de SSH Keys
  - Habilitar backups automáticos
  - Habilitar IPv6
  - Habilitar monitoring
  - Adicionar tags
- ✅ Ver detalhes completos do Droplet
  - Status (active, off, new, archive)
  - Informações de rede (IPs público e privado)
  - Recursos (CPU, RAM, disco)
  - Imagem utilizada
  - Tags
  - Recursos extras
- ✅ Executar ações no Droplet
  - Reboot (soft)
  - Power On
  - Power Off
  - Shutdown
  - Criar Snapshot
  - Habilitar Backups
- ✅ Deletar Droplet

### Snapshots e Backups
- ✅ Listar snapshots do Droplet
- ✅ Criar snapshot com nome customizado
- ✅ Listar backups automáticos do Droplet

### Recursos Adicionais
- ✅ Listar SSH Keys da conta
- ✅ Listar regiões disponíveis
- ✅ Listar tamanhos de Droplet disponíveis
- ✅ Listar imagens disponíveis (distribuições)
- ✅ API para gerenciar tags
- ✅ API para gerenciar volumes

## Como Usar

### 1. Obter API Key da DigitalOcean

1. Acesse https://cloud.digitalocean.com/account/api/tokens
2. Clique em "Generate New Token"
3. Dê um nome ao token e selecione as permissões necessárias (recomendado: Write)
4. Copie o token gerado (começa com `dop_v1_`)

### 2. Usar a Aplicação

1. Acesse a aplicação em http://localhost:3000
2. Insira sua API Key no campo "API Key"
3. Clique em "Conectar"
4. Você verá todos os seus Droplets listados

### 3. Criar um Novo Droplet

1. Clique no botão "Novo Droplet"
2. Preencha as informações:
   - **Nome**: Nome do seu Droplet (ex: web-server)
   - **Região**: Datacenter onde o Droplet será criado
   - **Tamanho**: Quantidade de recursos (vCPUs, RAM, disco)
   - **Imagem**: Sistema operacional (Ubuntu, Debian, CentOS, etc.)
   - **SSH Keys**: Selecione as chaves SSH para acesso
   - **Backups**: Habilita backups automáticos (custo adicional)
   - **IPv6**: Habilita suporte a IPv6
   - **Monitoring**: Habilita monitoramento avançado
3. Clique em "Criar Droplet"

### 4. Gerenciar um Droplet Existente

1. Clique no card de um Droplet para ver os detalhes
2. No modal de detalhes, você pode:
   - **Ações Rápidas**: Reboot, Power Off, Power On, Shutdown
   - **Snapshot**: Criar um snapshot do estado atual
   - **Backups**: Ver os backups automáticos
   - **Rede**: Ver e copiar os IPs
   - **Recursos**: Ver especificações de hardware
   - **Imagem**: Ver informações do sistema operacional
   - **Tags**: Ver tags aplicadas ao Droplet
   - **Zona de Perigo**: Deletar o Droplet

## Estrutura do Projeto

```
src/
├── app/
│   ├── api/
│   │   └── digitalocean/
│   │       ├── droplets/
│   │       │   ├── route.ts              # Listar e criar droplets
│   │       │   └── [id]/
│   │       │       ├── route.ts          # Obter e deletar droplet
│   │       │       ├── actions/route.ts  # Executar ações
│   │       │       ├── backups/route.ts  # Listar backups
│   │       │       ├── snapshots/route.ts # Listar e criar snapshots
│   │       │       ├── kernels/route.ts  # Listar kernels
│   │       │       ├── neighbors/route.ts # Listar neighbors
│   │       │       └── firewalls/route.ts # Listar firewalls
│   │       ├── regions/route.ts          # Listar regiões
│   │       ├── sizes/route.ts            # Listar tamanhos
│   │       ├── images/route.ts           # Listar imagens
│   │       ├── ssh-keys/route.ts         # Listar SSH keys
│   │       ├── tags/route.ts             # Gerenciar tags
│   │       ├── snapshots/route.ts        # Gerenciar snapshots
│   │       └── volumes/route.ts          # Gerenciar volumes
│   ├── layout.tsx
│   ├── page.tsx                           # Interface principal
│   └── globals.css
├── components/
│   └── ui/                               # Componentes shadcn/ui
├── lib/
│   ├── store/
│   │   └── digitalocean.ts               # Zustand store
│   └── utils.ts
└── types/
    └── digitalocean.ts                   # TypeScript types
```

## Tecnologias

- **Framework**: Next.js 15 com App Router
- **Linguagem**: TypeScript
- **Estilização**: Tailwind CSS 4
- **Componentes**: shadcn/ui (Radix UI + Tailwind)
- **Gerenciamento de Estado**: Zustand
- **API Routes**: Next.js API Routes
- **Toasts**: Sonner

## API Endpoints

Todos os endpoints aceitam o header `X-API-Key` com sua API Key da DigitalOcean.

### Droplets
- `GET /api/digitalocean/droplets` - Listar todos os droplets
- `POST /api/digitalocean/droplets` - Criar novo droplet
- `DELETE /api/digitalocean/droplets?tag={tag}` - Deletar droplets por tag
- `GET /api/digitalocean/droplets/{id}` - Obter droplet específico
- `DELETE /api/digitalocean/droplets/{id}` - Deletar droplet específico

### Ações
- `POST /api/digitalocean/droplets/{id}/actions` - Executar ação no droplet
  - Ações disponíveis: reboot, power_on, power_off, shutdown, snapshot, enable_backups

### Recursos
- `GET /api/digitalocean/droplets/{id}/backups` - Listar backups
- `GET /api/digitalocean/droplets/{id}/snapshots` - Listar snapshots
- `POST /api/digitalocean/droplets/{id}/snapshots` - Criar snapshot
- `GET /api/digitalocean/droplets/{id}/kernels` - Listar kernels
- `GET /api/digitalocean/droplets/{id}/neighbors` - Listar neighbors
- `GET /api/digitalocean/droplets/{id}/firewalls` - Listar firewalls

### Metadados
- `GET /api/digitalocean/regions` - Listar regiões disponíveis
- `GET /api/digitalocean/sizes` - Listar tamanhos disponíveis
- `GET /api/digitalocean/images?type={type}` - Listar imagens
- `GET /api/digitalocean/ssh-keys` - Listar SSH keys

### Outros Recursos
- `GET/POST /api/digitalocean/tags` - Gerenciar tags
- `GET/POST/DELETE /api/digitalocean/volumes` - Gerenciar volumes
- `GET/DELETE /api/digitalocean/snapshots` - Gerenciar snapshots

## Desenvolvimento

```bash
# Instalar dependências (se necessário)
bun install

# Executar servidor de desenvolvimento
bun run dev

# Verificar código com ESLint
bun run lint

# Build para produção
bun run build
```

## Notas

- A API Key nunca é armazenada em nenhum banco de dados
- A comunicação com a DigitalOcean API é feita via backend
- Todos os erros são tratados e exibidos como toasts na interface
- A aplicação é totalmente responsiva

## Documentação da API DigitalOcean

Para mais informações sobre a API da DigitalOcean, acesse:
https://docs.digitalocean.com/reference/api/

## Licença

Este projeto foi desenvolvido como exemplo de gerenciamento de infraestrutura cloud usando Next.js e DigitalOcean API.

export interface Droplet {
  id: number
  name: string
  memory: number
  vcpus: number
  disk: number
  locked: boolean
  status: 'new' | 'active' | 'off' | 'archive' | 'droplet'
  created_at: string
  features: string[]
  backup_ids: number[]
  snapshot_ids: number[]
  image: DropletImage
  size: DropletSize
  size_slug: string
  networks: {
    v4: DropletNetworkV4[]
    v6: DropletNetworkV6[]
  }
  region: Region
  tags: string[]
  volume_ids: string[]
}

export interface DropletImage {
  id: number
  name: string
  type: string
  distribution: string
  slug: string
  public: boolean
  regions: string[]
  created_at: string
  min_disk_size: number
  size_gigabytes: number
  description: string
  error_message?: string
}

export interface DropletSize {
  slug: string
  memory: number
  vcpus: number
  disk: number
  transfer: number
  price_monthly: number
  price_hourly: number
  available: boolean
  regions: string[]
}

export interface DropletNetworkV4 {
  ip_address: string
  netmask: string
  gateway: string
  type: 'private' | 'public'
}

export interface DropletNetworkV6 {
  ip_address: string
  netmask: number
  gateway: string
  type: 'private' | 'public'
}

export interface Region {
  slug: string
  name: string
  sizes: string[]
  available: boolean
  features: string[]
}

export interface SSHKey {
  id: number
  name: string
  fingerprint: string
  public_key: string
  created_at: string
}

export interface Snapshot {
  id: number
  name: string
  regions: string[]
  created_at: string
  resource_id: number
  resource_type: string
  min_disk_size: number
  size_gigabytes: number
  tags: string[]
}

export interface Tag {
  name: string
  resources_count: number
}

export interface Volume {
  id: string
  name: string
  size_gigabytes: number
  droplet_ids: number[]
  region: {
    name: string
    slug: string
  }
  filesystem_type: string
  filesystem_label: string
  created_at: string
}

export interface Action {
  id: number
  status: 'in-progress' | 'completed' | 'errored'
  type: string
  started_at: string
  completed_at: string | null
  resource_id: number
  resource_type: string
  region: {
    name: string
    slug: string
  }
  region_slug: string
}

export interface CreateDropletRequest {
  name: string
  region: string
  size: string
  image: string
  ssh_keys?: number[]
  backups?: boolean
  ipv6?: boolean
  monitoring?: boolean
  tags?: string[]
  volumes?: string[]
}

export interface DropletActionType {
  type: 'reboot' | 'power_on' | 'power_off' | 'shutdown' | 'password_reset' |
        'resize' | 'rebuild' | 'snapshot' | 'enable_backups' | 'disable_backups' |
        'change_kernel' | 'enable_ipv6' | 'disable_ipv6' | 'private_networking'
  size?: string
  image?: string
  snapshot_name?: string
  kernel?: number
}

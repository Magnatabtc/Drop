'use client'

// DigitalOcean Store
import { create } from 'zustand'

interface DigitalOceanStore {
  apiKey: string
  setApiKey: (key: string) => void
  isAuthenticated: boolean
}

export const useDigitalOceanStore = create<DigitalOceanStore>((set) => ({
  apiKey: '',
  setApiKey: (key: string) => set({ apiKey: key, isAuthenticated: !!key }),
  isAuthenticated: false,
}))

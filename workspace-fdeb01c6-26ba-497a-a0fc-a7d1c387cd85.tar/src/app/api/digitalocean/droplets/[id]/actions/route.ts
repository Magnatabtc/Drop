import { NextRequest, NextResponse } from 'next/server'

const DIGITALOCEAN_API_BASE = 'https://api.digitalocean.com/v2'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const apiKey = request.headers.get('X-API-Key')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  try {
    const response = await fetch(`${DIGITALOCEAN_API_BASE}/droplets/${params.id}/actions`, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao buscar ações' },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Erro ao buscar ações:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const apiKey = request.headers.get('X-API-Key')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  try {
    const body = await request.json()

    const response = await fetch(`${DIGITALOCEAN_API_BASE}/droplets/${params.id}/actions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao executar ação' },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Erro ao executar ação:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

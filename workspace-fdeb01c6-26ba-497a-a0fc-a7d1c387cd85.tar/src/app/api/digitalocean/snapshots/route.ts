import { NextRequest, NextResponse } from 'next/server'

const DIGITALOCEAN_API_BASE = 'https://api.digitalocean.com/v2'

export async function GET(request: NextRequest) {
  const apiKey = request.headers.get('X-API-Key')
  const searchParams = request.nextUrl.searchParams
  const resourceType = searchParams.get('resource_type')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  try {
    let url = `${DIGITALOCEAN_API_BASE}/snapshots`
    if (resourceType) {
      url += `?resource_type=${resourceType}`
    }

    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao buscar snapshots' },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Erro ao buscar snapshots:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const apiKey = request.headers.get('X-API-Key')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  try {
    const searchParams = request.nextUrl.searchParams
    const snapshotId = searchParams.get('id')

    if (!snapshotId) {
      return NextResponse.json({ error: 'ID do snapshot não fornecido' }, { status: 400 })
    }

    const response = await fetch(`${DIGITALOCEAN_API_BASE}/snapshots/${snapshotId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao deletar snapshot' },
        { status: response.status }
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Erro ao deletar snapshot:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'

const DIGITALOCEAN_API_BASE = 'https://api.digitalocean.com/v2'

export async function GET(request: NextRequest) {
  const apiKey = request.headers.get('X-API-Key')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  try {
    const response = await fetch(`${DIGITALOCEAN_API_BASE}/volumes`, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao buscar volumes' },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Erro ao buscar volumes:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  const apiKey = request.headers.get('X-API-Key')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  try {
    const body = await request.json()

    const response = await fetch(`${DIGITALOCEAN_API_BASE}/volumes`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao criar volume' },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Erro ao criar volume:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  const apiKey = request.headers.get('X-API-Key')
  const searchParams = request.nextUrl.searchParams
  const id = searchParams.get('id')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  if (!id) {
    return NextResponse.json({ error: 'ID do volume não fornecido' }, { status: 400 })
  }

  try {
    const response = await fetch(`${DIGITALOCEAN_API_BASE}/volumes/${id}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao deletar volume' },
        { status: response.status }
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Erro ao deletar volume:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

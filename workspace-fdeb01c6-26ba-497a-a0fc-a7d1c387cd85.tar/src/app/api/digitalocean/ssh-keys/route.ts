import { NextRequest, NextResponse } from 'next/server'

const DIGITALOCEAN_API_BASE = 'https://api.digitalocean.com/v2'

export async function GET(request: NextRequest) {
  const apiKey = request.headers.get('X-API-Key')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  try {
    const response = await fetch(`${DIGITALOCEAN_API_BASE}/account/keys`, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao buscar SSH keys' },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Erro ao buscar SSH keys:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  const apiKey = request.headers.get('X-API-Key')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  try {
    const body = await request.json()

    const response = await fetch(`${DIGITALOCEAN_API_BASE}/account/keys`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao criar SSH key' },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Erro ao criar SSH key:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

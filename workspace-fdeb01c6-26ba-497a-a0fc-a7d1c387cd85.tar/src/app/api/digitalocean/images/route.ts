import { NextRequest, NextResponse } from 'next/server'

const DIGITALOCEAN_API_BASE = 'https://api.digitalocean.com/v2'

export async function GET(request: NextRequest) {
  const apiKey = request.headers.get('X-API-Key')
  const searchParams = request.nextUrl.searchParams
  const type = searchParams.get('type')

  if (!apiKey) {
    return NextResponse.json({ error: 'API Key não fornecida' }, { status: 401 })
  }

  try {
    let url = `${DIGITALOCEAN_API_BASE}/images`
    if (type) {
      url += `?type=${type}`
    }

    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      const error = await response.json()
      return NextResponse.json(
        { error: error.message || 'Erro ao buscar imagens' },
        { status: response.status }
      )
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Erro ao buscar imagens:', error)
    return NextResponse.json(
      { error: 'Erro ao conectar com DigitalOcean API' },
      { status: 500 }
    )
  }
}

// DigitalOcean Droplet Management App - Updated
'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import { create } from 'zustand'
import { Droplet, Region, DropletSize, DropletImage, SSHKey } from '@/types/digitalocean'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { ScrollArea } from '@/components/ui/scroll-area'
import { toast } from 'sonner'
import { Loader2, Server, Plus, Power, RotateCw, Trash2, RefreshCw, Copy, Key, HardDrive, Tag as TagIcon, Zap, Camera } from 'lucide-react'

// Local store definition
const useDigitalOceanStore = create<{
  apiKey: string
  setApiKey: (key: string) => void
  isAuthenticated: boolean
}>((set) => ({
  apiKey: '',
  setApiKey: (key: string) => set({ apiKey: key, isAuthenticated: !!key }),
  isAuthenticated: false,
}))

export default function DigitalOceanManager() {
  const { apiKey, setApiKey, isAuthenticated } = useDigitalOceanStore()
  const [loading, setLoading] = useState(false)
  const [droplets, setDroplets] = useState<Droplet[]>([])
  const [regions, setRegions] = useState<Region[]>([])
  const [sizes, setSizes] = useState<DropletSize[]>([])
  const [images, setImages] = useState<DropletImage[]>([])
  const [sshKeys, setSSHKeys] = useState<SSHKey[]>([])
  const [selectedDroplet, setSelectedDroplet] = useState<Droplet | null>(null)
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false)
  const [snapshotDialogOpen, setSnapshotDialogOpen] = useState(false)
  const [backupsDialogOpen, setBackupsDialogOpen] = useState(false)
  const [snapshotName, setSnapshotName] = useState('')
  const [backups, setBackups] = useState<any[]>([])
  const [snapshots, setSnapshots] = useState<any[]>([])

  // Form state para criar droplet
  const [newDroplet, setNewDroplet] = useState({
    name: '',
    region: '',
    size: '',
    image: '',
    ssh_keys: [] as number[],
    backups: false,
    ipv6: false,
    monitoring: false,
    tags: [] as string[],
  })

  useEffect(() => {
    if (apiKey) {
      loadDroplets()
      loadRegions()
      loadSizes()
      loadImages()
      loadSSHKeys()
    }
  }, [apiKey])

  const loadDroplets = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/digitalocean/droplets', {
        headers: { 'X-API-Key': apiKey }
      })
      const data = await response.json()
      if (response.ok) {
        setDroplets(data.droplets)
        toast.success('Droplets carregados com sucesso')
      } else {
        toast.error(data.error || 'Erro ao carregar droplets')
      }
    } catch (error) {
      toast.error('Erro ao conectar com DigitalOcean API')
    } finally {
      setLoading(false)
    }
  }

  const loadRegions = async () => {
    try {
      const response = await fetch('/api/digitalocean/regions', {
        headers: { 'X-API-Key': apiKey }
      })
      const data = await response.json()
      if (response.ok) {
        setRegions(data.regions)
      }
    } catch (error) {
      console.error('Erro ao carregar regiões:', error)
    }
  }

  const loadSizes = async () => {
    try {
      const response = await fetch('/api/digitalocean/sizes', {
        headers: { 'X-API-Key': apiKey }
      })
      const data = await response.json()
      if (response.ok) {
        setSizes(data.sizes)
      }
    } catch (error) {
      console.error('Erro ao carregar tamanhos:', error)
    }
  }

  const loadImages = async () => {
    try {
      const response = await fetch('/api/digitalocean/images?type=distribution', {
        headers: { 'X-API-Key': apiKey }
      })
      const data = await response.json()
      if (response.ok) {
        setImages(data.images)
      }
    } catch (error) {
      console.error('Erro ao carregar imagens:', error)
    }
  }

  const loadSSHKeys = async () => {
    try {
      const response = await fetch('/api/digitalocean/ssh-keys', {
        headers: { 'X-API-Key': apiKey }
      })
      const data = await response.json()
      if (response.ok) {
        setSSHKeys(data.ssh_keys || data.sshKeys)
      }
    } catch (error) {
      console.error('Erro ao carregar SSH keys:', error)
    }
  }

  const handleCreateDroplet = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/digitalocean/droplets', {
        method: 'POST',
        headers: {
          'X-API-Key': apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newDroplet),
      })
      const data = await response.json()
      if (response.ok) {
        toast.success('Droplet criado com sucesso!')
        setCreateDialogOpen(false)
        loadDroplets()
        setNewDroplet({
          name: '',
          region: '',
          size: '',
          image: '',
          ssh_keys: [],
          backups: false,
          ipv6: false,
          monitoring: false,
          tags: [],
        })
      } else {
        toast.error(data.error || 'Erro ao criar droplet')
      }
    } catch (error) {
      toast.error('Erro ao criar droplet')
    } finally {
      setLoading(false)
    }
  }

  const handleDropletAction = async (dropletId: number, action: string, params?: any) => {
    setLoading(true)
    try {
      const body = params ? { type: action, ...params } : { type: action }
      const response = await fetch(`/api/digitalocean/droplets/${dropletId}/actions`, {
        method: 'POST',
        headers: {
          'X-API-Key': apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      })
      const data = await response.json()
      if (response.ok) {
        toast.success(`Ação iniciada com sucesso`)
        loadDroplets()
      } else {
        toast.error(data.error || 'Erro ao executar ação')
      }
    } catch (error) {
      toast.error('Erro ao executar ação')
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteDroplet = async (dropletId: number) => {
    if (!confirm('Tem certeza que deseja deletar este droplet?')) return

    setLoading(true)
    try {
      const response = await fetch(`/api/digitalocean/droplets/${dropletId}`, {
        method: 'DELETE',
        headers: { 'X-API-Key': apiKey },
      })
      if (response.ok) {
        toast.success('Droplet deletado com sucesso')
        loadDroplets()
        setDetailsDialogOpen(false)
      } else {
        toast.error('Erro ao deletar droplet')
      }
    } catch (error) {
      toast.error('Erro ao deletar droplet')
    } finally {
      setLoading(false)
    }
  }

  const handleCreateSnapshot = async () => {
    if (!snapshotName) {
      toast.error('Por favor, forneça um nome para o snapshot')
      return
    }

    setLoading(true)
    try {
      const response = await fetch(`/api/digitalocean/droplets/${selectedDroplet?.id}/snapshots`, {
        method: 'POST',
        headers: {
          'X-API-Key': apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: snapshotName }),
      })
      if (response.ok) {
        toast.success('Snapshot criado com sucesso!')
        setSnapshotDialogOpen(false)
        setSnapshotName('')
        loadDropletSnapshots()
      } else {
        const data = await response.json()
        toast.error(data.error || 'Erro ao criar snapshot')
      }
    } catch (error) {
      toast.error('Erro ao criar snapshot')
    } finally {
      setLoading(false)
    }
  }

  const loadDropletBackups = async () => {
    if (!selectedDroplet) return

    try {
      const response = await fetch(`/api/digitalocean/droplets/${selectedDroplet.id}/backups`, {
        headers: { 'X-API-Key': apiKey }
      })
      const data = await response.json()
      if (response.ok) {
        setBackups(data.backups || [])
      }
    } catch (error) {
      console.error('Erro ao carregar backups:', error)
    }
  }

  const loadDropletSnapshots = async () => {
    if (!selectedDroplet) return

    try {
      const response = await fetch(`/api/digitalocean/droplets/${selectedDroplet.id}/snapshots`, {
        headers: { 'X-API-Key': apiKey }
      })
      const data = await response.json()
      if (response.ok) {
        setSnapshots(data.snapshots || [])
      }
    } catch (error) {
      console.error('Erro ao carregar snapshots:', error)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('Copiado para a área de transferência')
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500'
      case 'off': return 'bg-gray-500'
      case 'new': return 'bg-blue-500'
      case 'archive': return 'bg-yellow-500'
      default: return 'bg-red-500'
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl flex items-center gap-2">
              <Server className="w-6 h-6" />
              DigitalOcean Manager
            </CardTitle>
            <CardDescription>
              Insira sua API Key para gerenciar seus Droplets
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="apiKey">API Key</Label>
              <Input
                id="apiKey"
                type="password"
                placeholder="dop_v1_xxxxxxxxxxxx"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
              />
            </div>
            <Button
              onClick={() => setApiKey(apiKey)}
              className="w-full"
              disabled={!apiKey}
            >
              Conectar
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Server className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold">DigitalOcean Manager</h1>
              <p className="text-muted-foreground">Gerencie seus Droplets</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={loadDroplets}
              disabled={loading}
            >
              {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
              Atualizar
            </Button>
            <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Novo Droplet
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh]">
                <DialogHeader>
                  <DialogTitle>Criar Novo Droplet</DialogTitle>
                  <DialogDescription>
                    Configure as especificações do seu novo Droplet
                  </DialogDescription>
                </DialogHeader>
                <ScrollArea className="max-h-[70vh] pr-4">
                  <div className="space-y-6 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="dropletName">Nome do Droplet</Label>
                      <Input
                        id="dropletName"
                        placeholder="my-droplet"
                        value={newDroplet.name}
                        onChange={(e) => setNewDroplet({ ...newDroplet, name: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="region">Região</Label>
                      <Select
                        value={newDroplet.region}
                        onValueChange={(value) => setNewDroplet({ ...newDroplet, region: value })}
                      >
                        <SelectTrigger id="region">
                          <SelectValue placeholder="Selecione uma região" />
                        </SelectTrigger>
                        <SelectContent>
                          {regions.map((region) => (
                            <SelectItem key={region.slug} value={region.slug}>
                              {region.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="size">Tamanho</Label>
                      <Select
                        value={newDroplet.size}
                        onValueChange={(value) => setNewDroplet({ ...newDroplet, size: value })}
                      >
                        <SelectTrigger id="size">
                          <SelectValue placeholder="Selecione o tamanho" />
                        </SelectTrigger>
                        <SelectContent>
                          {sizes.filter(s => s.available).map((size) => (
                            <SelectItem key={size.slug} value={size.slug}>
                              {size.slug} - {size.vcpus} vCPUs, {size.memory / 1024}GB RAM - ${size.price_monthly}/mês
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="image">Imagem (Sistema Operacional)</Label>
                      <Select
                        value={newDroplet.image}
                        onValueChange={(value) => setNewDroplet({ ...newDroplet, image: value })}
                      >
                        <SelectTrigger id="image">
                          <SelectValue placeholder="Selecione a imagem" />
                        </SelectTrigger>
                        <SelectContent>
                          {images.filter(i => i.distribution).map((image) => (
                            <SelectItem key={image.slug} value={image.slug}>
                              {image.distribution} - {image.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>SSH Keys</Label>
                      <div className="space-y-2">
                        {sshKeys.map((key) => (
                          <div key={key.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`ssh-${key.id}`}
                              checked={newDroplet.ssh_keys.includes(key.id)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setNewDroplet({
                                    ...newDroplet,
                                    ssh_keys: [...newDroplet.ssh_keys, key.id],
                                  })
                                } else {
                                  setNewDroplet({
                                    ...newDroplet,
                                    ssh_keys: newDroplet.ssh_keys.filter((k) => k !== key.id),
                                  })
                                }
                              }}
                            />
                            <Label htmlFor={`ssh-${key.id}`} className="flex-1">
                              {key.name}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="backups"
                          checked={newDroplet.backups}
                          onCheckedChange={(checked) => setNewDroplet({ ...newDroplet, backups: !!checked })}
                        />
                        <Label htmlFor="backups">Habilitar Backups Automáticos</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="ipv6"
                          checked={newDroplet.ipv6}
                          onCheckedChange={(checked) => setNewDroplet({ ...newDroplet, ipv6: !!checked })}
                        />
                        <Label htmlFor="ipv6">Habilitar IPv6</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="monitoring"
                          checked={newDroplet.monitoring}
                          onCheckedChange={(checked) => setNewDroplet({ ...newDroplet, monitoring: !!checked })}
                        />
                        <Label htmlFor="monitoring">Habilitar Monitoring</Label>
                      </div>
                    </div>
                  </div>
                </ScrollArea>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleCreateDroplet} disabled={loading || !newDroplet.name || !newDroplet.region || !newDroplet.size || !newDroplet.image}>
                    {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : 'Criar Droplet'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Droplets</CardTitle>
              <Server className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{droplets.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Ativos</CardTitle>
              <Zap className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {droplets.filter((d) => d.status === 'active').length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Desligados</CardTitle>
              <Power className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-600">
                {droplets.filter((d) => d.status === 'off').length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Volumes</CardTitle>
              <HardDrive className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {droplets.reduce((acc, d) => acc + d.volume_ids.length, 0)}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Droplets Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {droplets.map((droplet) => (
            <Card
              key={droplet.id}
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => {
                setSelectedDroplet(droplet)
                setDetailsDialogOpen(true)
              }}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${getStatusColor(droplet.status)}`} />
                    <CardTitle className="text-lg">{droplet.name}</CardTitle>
                  </div>
                  <Badge variant="outline">{droplet.status}</Badge>
                </div>
                <CardDescription className="flex items-center gap-2">
                  <Server className="w-3 h-3" />
                  {droplet.size_slug}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">IP Público</span>
                  <div className="flex items-center gap-1">
                    <span className="font-mono">
                      {droplet.networks.v4.find((n) => n.type === 'public')?.ip_address || 'N/A'}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0"
                      onClick={(e) => {
                        e.stopPropagation()
                        copyToClipboard(droplet.networks.v4.find((n) => n.type === 'public')?.ip_address || '')
                      }}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Região</span>
                  <span>{droplet.region.name}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">SO</span>
                  <span>{droplet.image.distribution}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Recursos</span>
                  <span>{droplet.vcpus} vCPUs, {droplet.memory / 1024}GB RAM</span>
                </div>
                {droplet.tags.length > 0 && (
                  <div className="flex items-center gap-2 flex-wrap">
                    {droplet.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        <TagIcon className="w-3 h-3 mr-1" />
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {droplets.length === 0 && !loading && (
          <Card className="p-12">
            <div className="text-center space-y-4">
              <Server className="w-16 h-16 mx-auto text-muted-foreground" />
              <div>
                <h3 className="text-xl font-semibold mb-2">Nenhum Droplet encontrado</h3>
                <p className="text-muted-foreground">
                  Crie seu primeiro Droplet para começar a gerenciar sua infraestrutura
                </p>
              </div>
              <Button onClick={() => setCreateDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Criar Primeiro Droplet
              </Button>
            </div>
          </Card>
        )}

        {/* Details Dialog */}
        <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Server className="w-5 h-5" />
                {selectedDroplet?.name}
              </DialogTitle>
              <DialogDescription>
                Detalhes e ações do Droplet
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="max-h-[70vh] pr-4">
              {selectedDroplet && (
                <div className="space-y-6 py-4">
                  {/* Status Card */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Status</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Estado</span>
                        <Badge className={`flex items-center gap-1`}>
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(selectedDroplet.status)}`} />
                          {selectedDroplet.status}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">ID</span>
                        <span className="font-mono">{selectedDroplet.id}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Criado em</span>
                        <span>{new Date(selectedDroplet.created_at).toLocaleDateString('pt-BR')}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Bloqueado</span>
                        <Badge variant={selectedDroplet.locked ? 'destructive' : 'default'}>
                          {selectedDroplet.locked ? 'Sim' : 'Não'}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Actions */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Ações Rápidas</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDropletAction(selectedDroplet.id, 'reboot')}
                          disabled={loading}
                        >
                          <RotateCw className="w-4 h-4 mr-2" />
                          Reboot
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDropletAction(selectedDroplet.id, 'power_off')}
                          disabled={loading}
                        >
                          <Power className="w-4 h-4 mr-2" />
                          Power Off
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDropletAction(selectedDroplet.id, 'power_on')}
                          disabled={loading}
                        >
                          <Zap className="w-4 h-4 mr-2" />
                          Power On
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDropletAction(selectedDroplet.id, 'shutdown')}
                          disabled={loading}
                        >
                          <Power className="w-4 h-4 mr-2" />
                          Shutdown
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Network */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Rede</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {selectedDroplet.networks.v4.map((network, idx) => (
                        <div key={idx} className="flex items-center justify-between">
                          <span className="text-muted-foreground">IP {network.type}</span>
                          <div className="flex items-center gap-1">
                            <span className="font-mono">{network.ip_address}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={() => copyToClipboard(network.ip_address)}
                            >
                              <Copy className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Resources */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Recursos</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-muted-foreground text-sm">CPU</span>
                          <p className="text-lg font-semibold">{selectedDroplet.vcpus} vCPUs</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground text-sm">Memória</span>
                          <p className="text-lg font-semibold">{selectedDroplet.memory / 1024} GB</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground text-sm">Disco</span>
                          <p className="text-lg font-semibold">{selectedDroplet.disk} GB</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground text-sm">Plano</span>
                          <p className="text-lg font-semibold">{selectedDroplet.size_slug}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Image */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Imagem</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Distribuição</span>
                        <span>{selectedDroplet.image.distribution}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Nome</span>
                        <span>{selectedDroplet.image.name}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Slug</span>
                        <span className="font-mono text-sm">{selectedDroplet.image.slug}</span>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Tags */}
                  {selectedDroplet.tags.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base flex items-center gap-2">
                          <TagIcon className="w-4 h-4" />
                          Tags
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-2 flex-wrap">
                          {selectedDroplet.tags.map((tag) => (
                            <Badge key={tag} variant="secondary">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Features */}
                  {selectedDroplet.features.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Recursos Extras</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-2 flex-wrap">
                          {selectedDroplet.features.map((feature) => (
                            <Badge key={feature} variant="outline">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Danger Zone */}
                  <Card className="border-destructive">
                    <CardHeader>
                      <CardTitle className="text-base text-destructive">Zona de Perigo</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Button
                        variant="destructive"
                        onClick={() => handleDeleteDroplet(selectedDroplet.id)}
                        disabled={loading}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Deletar Droplet
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              )}
            </ScrollArea>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}

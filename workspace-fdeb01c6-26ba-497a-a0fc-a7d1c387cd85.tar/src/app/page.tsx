'use client'

import { useState, useEffect } from 'react'
import { Droplet, Region, DropletSize, DropletImage, SSHKey } from '@/types/digitalocean'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'
import { Loader2, Server, Plus, Power, RotateCw, Trash2, RefreshCw, Copy, Tag as TagIcon, Zap, HardDrive } from 'lucide-react'

export default function DigitalOceanManager() {
  const [apiKey, setApiKey] = useState('')
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loading, setLoading] = useState(false)
  const [droplets, setDroplets] = useState<Droplet[]>([])
  const [regions, setRegions] = useState<Region[]>([])
  const [sizes, setSizes] = useState<DropletSize[]>([])
  const [images, setImages] = useState<DropletImage[]>([])
  const [sshKeys, setSSHKeys] = useState<SSHKey[]>([])

  const handleConnect = () => {
    if (apiKey) {
      setIsAuthenticated(true)
      toast.success('Conectado ao DigitalOcean')
    }
  }

  useEffect(() => {
    if (isAuthenticated && apiKey) {
      loadData()
    }
  }, [isAuthenticated, apiKey])

  const loadData = async () => {
    try {
      const [drops, regs, sizs, imgs, keys] = await Promise.all([
        fetch('/api/digitalocean/droplets', { headers: { 'X-API-Key': apiKey } }),
        fetch('/api/digitalocean/regions', { headers: { 'X-API-Key': apiKey } }),
        fetch('/api/digitalocean/sizes', { headers: { 'X-API-Key': apiKey } }),
        fetch('/api/digitalocean/images?type=distribution', { headers: { 'X-API-Key': apiKey } }),
        fetch('/api/digitalocean/ssh-keys', { headers: { 'X-API-Key': apiKey } }),
      ])

      const dropsData = await drops.json()
      const regsData = await regs.json()
      const sizsData = await sizs.json()
      const imgsData = await imgs.json()
      const keysData = await keys.json()

      if (drops.ok) setDroplets(dropsData.droplets || [])
      if (regs.ok) setRegions(regsData.regions || [])
      if (sizs.ok) setSizes(sizsData.sizes || [])
      if (imgs.ok) setImages(imgsData.images || [])
      if (keys.ok) setSSHKeys(keysData.ssh_keys || keysData.sshKeys || [])
    } catch (error) {
      toast.error('Erro ao carregar dados')
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500'
      case 'off': return 'bg-gray-500'
      case 'new': return 'bg-blue-500'
      default: return 'bg-red-500'
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="w-6 h-6" />
              DigitalOcean Manager
            </CardTitle>
            <CardDescription>
              Insira sua API Key para gerenciar seus Droplets
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              type="password"
              placeholder="dop_v1_xxxxxxxxxxxx"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
            />
            <Button onClick={handleConnect} className="w-full" disabled={!apiKey}>
              Conectar
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Server className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold">DigitalOcean Manager</h1>
              <p className="text-muted-foreground">Gerencie seus Droplets</p>
            </div>
          </div>
          <Button onClick={loadData} disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            Atualizar
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Total</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{droplets.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Ativos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {droplets.filter((d) => d.status === 'active').length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Desligados</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-600">
                {droplets.filter((d) => d.status === 'off').length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">Volumes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {droplets.reduce((acc, d) => acc + d.volume_ids.length, 0)}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {droplets.map((droplet) => (
            <Card key={droplet.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${getStatusColor(droplet.status)}`} />
                    <CardTitle className="text-lg">{droplet.name}</CardTitle>
                  </div>
                  <Badge variant="outline">{droplet.status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">IP Público</span>
                  <span className="font-mono">
                    {droplet.networks.v4.find((n) => n.type === 'public')?.ip_address || 'N/A'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Região</span>
                  <span>{droplet.region.name}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">SO</span>
                  <span>{droplet.image.distribution}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {droplets.length === 0 && !loading && (
          <Card className="p-12">
            <div className="text-center space-y-4">
              <Server className="w-16 h-16 mx-auto text-muted-foreground" />
              <div>
                <h3 className="text-xl font-semibold mb-2">Nenhum Droplet encontrado</h3>
                <p className="text-muted-foreground">
                  Crie seu primeiro Droplet para começar
                </p>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}

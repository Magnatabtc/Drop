'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Cloud, Key, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

interface ApiKeyInputProps {
  onSave: (apiKey: string) => void;
}

export function ApiKeyInput({ onSave }: ApiKeyInputProps) {
  const [apiKey, setApiKey] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!apiKey.trim()) return;

    setError(null);
    setIsLoading(true);
    try {
      const response = await fetch('/api/digitalocean/account', {
        headers: { 'x-api-key': apiKey.trim() }
      });

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.message || data.error || 'Invalid API key');
      }

      onSave(apiKey.trim());
      toast.success('API key validated successfully');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to validate API key';
      setError(message);
      toast.error(message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted/20 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto p-3 bg-primary/10 rounded-full w-fit">
            <Cloud className="h-8 w-8 text-primary" />
          </div>
          <CardTitle>DigitalOcean Manager</CardTitle>
          <CardDescription>
            Enter your DigitalOcean API key to manage your resources
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="flex items-center gap-2 p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive text-sm">
                <AlertCircle className="h-4 w-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="space-y-2">
              <label htmlFor="apiKey" className="text-sm font-medium">
                API Key
              </label>
              <div className="relative">
                <Key className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="apiKey"
                  type="password"
                  placeholder="dop_v1_..."
                  className="pl-10"
                  value={apiKey}
                  onChange={(e) => {
                    setApiKey(e.target.value);
                    setError(null);
                  }}
                  disabled={isLoading}
                />
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={isLoading || !apiKey.trim()}>
              {isLoading ? 'Validating...' : 'Connect to DigitalOcean'}
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              Get your API key from{' '}
              <a
                href="https://cloud.digitalocean.com/account/api/tokens"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                DigitalOcean Control Panel
              </a>
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import {
  HardDrive, Plus, RefreshCw, Trash2, Globe, Shield, Key, Camera,
  Database, Tag as TagIcon, Folder, Server, Clock
} from 'lucide-react';
import type { Volume, LoadBalancer, Domain, FloatingIP, Firewall, SSHKey, Snapshot, Project, Tag } from '@/types/digitalocean';

interface OtherResourcesPanelProps {
  apiKey: string;
}

export function OtherResourcesPanel({ apiKey }: OtherResourcesPanelProps) {
  const [volumes, setVolumes] = useState<Volume[]>([]);
  const [loadBalancers, setLoadBalancers] = useState<LoadBalancer[]>([]);
  const [domains, setDomains] = useState<Domain[]>([]);
  const [floatingIPs, setFloatingIPs] = useState<FloatingIP[]>([]);
  const [firewalls, setFirewalls] = useState<Firewall[]>([]);
  const [sshKeys, setSshKeys] = useState<SSHKey[]>([]);
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState('volumes');

  // Create resource form states
  const [newVolume, setNewVolume] = useState({ name: '', size: 10, region: 'nyc1' });
  const [newDomain, setNewDomain] = useState({ name: '', ip: '' });
  const [newSshKey, setNewSshKey] = useState({ name: '', publicKey: '' });
  const [newTag, setNewTag] = useState({ name: '' });
  const [newProject, setNewProject] = useState({ name: '', description: '', purpose: '', environment: 'Development' as const });

  const fetchAllResources = async () => {
    try {
      const [v, lb, d, fip, fw, sk, sn, pr, tg] = await Promise.all([
        fetch('/api/digitalocean/volumes', { headers: { 'x-api-key': apiKey } }),
        fetch('/api/digitalocean/load-balancers', { headers: { 'x-api-key': apiKey } }),
        fetch('/api/digitalocean/domains', { headers: { 'x-api-key': apiKey } }),
        fetch('/api/digitalocean/floating-ips', { headers: { 'x-api-key': apiKey } }),
        fetch('/api/digitalocean/firewalls', { headers: { 'x-api-key': apiKey } }),
        fetch('/api/digitalocean/ssh-keys', { headers: { 'x-api-key': apiKey } }),
        fetch('/api/digitalocean/snapshots', { headers: { 'x-api-key': apiKey } }),
        fetch('/api/digitalocean/projects', { headers: { 'x-api-key': apiKey } }),
        fetch('/api/digitalocean/tags', { headers: { 'x-api-key': apiKey } }),
      ]);

      const [vData, lbData, dData, fipData, fwData, skData, snData, prData, tgData] = await Promise.all([
        v.json(), lb.json(), d.json(), fip.json(), fw.json(), sk.json(), sn.json(), pr.json(), tg.json()
      ]);

      setVolumes(vData.volumes || []);
      setLoadBalancers(lbData.load_balancers || []);
      setDomains(dData.domains || []);
      setFloatingIPs(fipData.floating_ips || []);
      setFirewalls(fwData.firewalls || []);
      setSshKeys(skData.ssh_keys || skData.ssh_keys || []);
      setSnapshots(snData.snapshots || []);
      setProjects(prData.projects || []);
      setTags(tgData.tags || []);
    } catch (error) {
      console.error('Failed to fetch resources:', error);
      toast.error('Failed to fetch resources');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllResources();
  }, [apiKey]);

  const handleDelete = async (type: string, id: string, name?: string) => {
    if (!confirm(`Are you sure you want to delete this ${type}?`)) return;

    setIsDeleting(id);
    try {
      const endpoint = `/api/digitalocean/${type === 'ssh-keys' ? 'ssh-keys' : type.replace('_', '-')}`;
      const response = await fetch(`${endpoint}?${name ? 'name=' + name : 'id=' + id}`, {
        method: 'DELETE',
        headers: { 'x-api-key': apiKey },
      });

      if (!response.ok) throw new Error('Delete failed');
      toast.success(`${type} deleted successfully`);
      fetchAllResources();
    } catch (error) {
      toast.error(`Failed to delete ${type}`);
    } finally {
      setIsDeleting(null);
    }
  };

  const handleCreateVolume = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/digitalocean/volumes', {
        method: 'POST',
        headers: { 'x-api-key': apiKey },
        body: JSON.stringify(newVolume),
      });

      if (!response.ok) throw new Error('Create failed');
      toast.success('Volume created successfully');
      setNewVolume({ name: '', size: 10, region: 'nyc1' });
      fetchAllResources();
    } catch (error) {
      toast.error('Failed to create volume');
    }
  };

  const handleCreateDomain = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/digitalocean/domains', {
        method: 'POST',
        headers: { 'x-api-key': apiKey },
        body: JSON.stringify({ name: newDomain.name, ip_address: newDomain.ip || undefined }),
      });

      if (!response.ok) throw new Error('Create failed');
      toast.success('Domain created successfully');
      setNewDomain({ name: '', ip: '' });
      fetchAllResources();
    } catch (error) {
      toast.error('Failed to create domain');
    }
  };

  const handleCreateSshKey = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/digitalocean/ssh-keys', {
        method: 'POST',
        headers: { 'x-api-key': apiKey },
        body: JSON.stringify({ name: newSshKey.name, public_key: newSshKey.publicKey }),
      });

      if (!response.ok) throw new Error('Create failed');
      toast.success('SSH key added successfully');
      setNewSshKey({ name: '', publicKey: '' });
      fetchAllResources();
    } catch (error) {
      toast.error('Failed to add SSH key');
    }
  };

  const handleCreateTag = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/digitalocean/tags', {
        method: 'POST',
        headers: { 'x-api-key': apiKey },
        body: JSON.stringify({ name: newTag.name }),
      });

      if (!response.ok) throw new Error('Create failed');
      toast.success('Tag created successfully');
      setNewTag({ name: '' });
      fetchAllResources();
    } catch (error) {
      toast.error('Failed to create tag');
    }
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/digitalocean/projects', {
        method: 'POST',
        headers: { 'x-api-key': apiKey },
        body: JSON.stringify(newProject),
      });

      if (!response.ok) throw new Error('Create failed');
      toast.success('Project created successfully');
      setNewProject({ name: '', description: '', purpose: '', environment: 'Development' });
      fetchAllResources();
    } catch (error) {
      toast.error('Failed to create project');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-pulse text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Other Resources</h2>
          <p className="text-muted-foreground">Manage your DigitalOcean resources</p>
        </div>
        <Button variant="outline" onClick={fetchAllResources}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh All
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 lg:grid-cols-9">
          <TabsTrigger value="volumes">Volumes</TabsTrigger>
          <TabsTrigger value="load-balancers">Load Balancers</TabsTrigger>
          <TabsTrigger value="domains">Domains</TabsTrigger>
          <TabsTrigger value="floating-ips">Floating IPs</TabsTrigger>
          <TabsTrigger value="firewalls">Firewalls</TabsTrigger>
          <TabsTrigger value="ssh-keys">SSH Keys</TabsTrigger>
          <TabsTrigger value="snapshots">Snapshots</TabsTrigger>
          <TabsTrigger value="projects">Projects</TabsTrigger>
          <TabsTrigger value="tags">Tags</TabsTrigger>
        </TabsList>

        {/* Volumes */}
        <TabsContent value="volumes">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Volumes</CardTitle>
                <CardDescription>Block storage volumes</CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Create Volume
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Volume</DialogTitle>
                    <DialogDescription>Add a new block storage volume</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateVolume} className="space-y-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        value={newVolume.name}
                        onChange={(e) => setNewVolume({ ...newVolume, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Size (GB)</Label>
                      <Input
                        type="number"
                        min="1"
                        value={newVolume.size}
                        onChange={(e) => setNewVolume({ ...newVolume, size: parseInt(e.target.value) })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Region</Label>
                      <select
                        className="w-full p-2 border rounded"
                        value={newVolume.region}
                        onChange={(e) => setNewVolume({ ...newVolume, region: e.target.value })}
                      >
                        <option value="nyc1">New York 1</option>
                        <option value="nyc3">New York 3</option>
                        <option value="ams3">Amsterdam 3</option>
                        <option value="sfo3">San Francisco 3</option>
                        <option value="lon1">London 1</option>
                        <option value="fra1">Frankfurt 1</option>
                        <option value="sgp1">Singapore 1</option>
                        <option value="blr1">Bangalore 1</option>
                      </select>
                    </div>
                    <Button type="submit" className="w-full">Create</Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {volumes.map((volume) => (
                  <Card key={volume.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <HardDrive className="h-5 w-5 text-muted-foreground" />
                          <span className="font-semibold">{volume.name}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete('volumes', volume.id)}
                          disabled={isDeleting === volume.id}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="space-y-1 text-sm text-muted-foreground">
                        <p>{volume.size_gigabytes} GB</p>
                        <p>{volume.region.slug}</p>
                        <p>Attached to: {volume.droplet_ids.length} droplets</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {volumes.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No volumes found</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Load Balancers */}
        <TabsContent value="load-balancers">
          <Card>
            <CardHeader>
              <CardTitle>Load Balancers</CardTitle>
              <CardDescription>Distribute traffic across droplets</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {loadBalancers.map((lb) => (
                  <Card key={lb.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <Server className="h-5 w-5 text-muted-foreground" />
                          <span className="font-semibold">{lb.name}</span>
                        </div>
                        <Badge variant={lb.status === 'active' ? 'default' : 'secondary'}>
                          {lb.status}
                        </Badge>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">IP:</span>
                          <span className="font-mono">{lb.ip}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Region:</span>
                          <span>{lb.region.slug}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Droplets:</span>
                          <span>{lb.droplet_ids.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Rules:</span>
                          <span>{lb.forwarding_rules.length}</span>
                        </div>
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        className="mt-4 w-full"
                        onClick={() => handleDelete('load-balancers', lb.id)}
                        disabled={isDeleting === lb.id}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {loadBalancers.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No load balancers found</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Domains */}
        <TabsContent value="domains">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Domains</CardTitle>
                <CardDescription>Manage DNS domains</CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Domain
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Domain</DialogTitle>
                    <DialogDescription>Add a new domain to your account</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateDomain} className="space-y-4">
                    <div className="space-y-2">
                      <Label>Domain Name</Label>
                      <Input
                        placeholder="example.com"
                        value={newDomain.name}
                        onChange={(e) => setNewDomain({ ...newDomain, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>IP Address (Optional)</Label>
                      <Input
                        placeholder="192.0.2.1"
                        value={newDomain.ip}
                        onChange={(e) => setNewDomain({ ...newDomain, ip: e.target.value })}
                      />
                    </div>
                    <Button type="submit" className="w-full">Add Domain</Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {domains.map((domain) => (
                  <Card key={domain.name}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Globe className="h-5 w-5 text-muted-foreground" />
                          <span className="font-semibold">{domain.name}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete('domains', domain.name, domain.name)}
                          disabled={isDeleting === domain.name}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-sm text-muted-foreground">TTL: {domain.ttl}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {domains.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No domains found</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Floating IPs */}
        <TabsContent value="floating-ips">
          <Card>
            <CardHeader>
              <CardTitle>Floating IPs</CardTitle>
              <CardDescription>Static IP addresses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {floatingIPs.map((fip) => (
                  <Card key={fip.ip}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Globe className="h-4 w-4 text-muted-foreground" />
                            <span className="font-mono font-semibold">{fip.ip}</span>
                          </div>
                          <div className="space-y-1 text-sm">
                            <p className="text-muted-foreground">
                              Region: <span className="font-medium">{fip.region.slug}</span>
                            </p>
                            <p className="text-muted-foreground">
                              Assigned: <span className="font-medium">{fip.droplet ? fip.droplet.name : 'None'}</span>
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete('floating-ips', fip.ip)}
                          disabled={isDeleting === fip.ip}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {floatingIPs.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No floating IPs found</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Firewalls */}
        <TabsContent value="firewalls">
          <Card>
            <CardHeader>
              <CardTitle>Firewalls</CardTitle>
              <CardDescription>Manage firewall rules</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {firewalls.map((fw) => (
                  <Card key={fw.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <Shield className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <span className="font-semibold">{fw.name}</span>
                            <Badge variant={fw.status === 'active' ? 'default' : 'secondary'} className="ml-2">
                              {fw.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-2 text-sm mb-4">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Inbound Rules:</span>
                          <span>{fw.inbound_rules.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Outbound Rules:</span>
                          <span>{fw.outbound_rules.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Droplets:</span>
                          <span>{fw.droplet_ids.length}</span>
                        </div>
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        className="w-full"
                        onClick={() => handleDelete('firewalls', fw.id)}
                        disabled={isDeleting === fw.id}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {firewalls.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No firewalls found</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* SSH Keys */}
        <TabsContent value="ssh-keys">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>SSH Keys</CardTitle>
                <CardDescription>Manage SSH public keys</CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Key
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add SSH Key</DialogTitle>
                    <DialogDescription>Add a new SSH public key</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateSshKey} className="space-y-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        placeholder="My Laptop"
                        value={newSshKey.name}
                        onChange={(e) => setNewSshKey({ ...newSshKey, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Public Key</Label>
                      <textarea
                        className="w-full p-2 border rounded min-h-24 text-xs"
                        placeholder="ssh-rsa AAAA..."
                        value={newSshKey.publicKey}
                        onChange={(e) => setNewSshKey({ ...newSshKey, publicKey: e.target.value })}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full">Add Key</Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {sshKeys.map((key) => (
                  <Card key={key.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Key className="h-4 w-4 text-muted-foreground" />
                            <span className="font-semibold">{key.name}</span>
                          </div>
                          <div className="text-xs text-muted-foreground font-mono break-all">
                            {key.public_key.substring(0, 60)}...
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            Fingerprint: {key.fingerprints[0]?.substring(0, 20)}...
                          </div>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete('ssh-keys', String(key.id))}
                          disabled={isDeleting === String(key.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {sshKeys.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No SSH keys found</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Snapshots */}
        <TabsContent value="snapshots">
          <Card>
            <CardHeader>
              <CardTitle>Snapshots</CardTitle>
              <CardDescription>Volume and droplet snapshots</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {snapshots.map((snap) => (
                  <Card key={snap.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Camera className="h-4 w-4 text-muted-foreground" />
                            <span className="font-semibold">{snap.name}</span>
                            <Badge variant="outline">{snap.resource_type}</Badge>
                          </div>
                          <div className="space-y-1 text-sm">
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <HardDrive className="h-3 w-3" />
                              <span>{snap.size_gigabytes} GB</span>
                            </div>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              <span>{new Date(snap.created_at).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete('snapshots', snap.id)}
                          disabled={isDeleting === snap.id}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {snapshots.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No snapshots found</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Projects */}
        <TabsContent value="projects">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Projects</CardTitle>
                <CardDescription>Organize your resources</CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    New Project
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Project</DialogTitle>
                    <DialogDescription>Create a new project to organize your resources</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateProject} className="space-y-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input
                        placeholder="My Project"
                        value={newProject.name}
                        onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Description</Label>
                      <Input
                        placeholder="Project description"
                        value={newProject.description}
                        onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Purpose</Label>
                      <Input
                        placeholder="Web Application"
                        value={newProject.purpose}
                        onChange={(e) => setNewProject({ ...newProject, purpose: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Environment</Label>
                      <select
                        className="w-full p-2 border rounded"
                        value={newProject.environment}
                        onChange={(e) => setNewProject({ ...newProject, environment: e.target.value as any })}
                      >
                        <option value="Development">Development</option>
                        <option value="Staging">Staging</option>
                        <option value="Production">Production</option>
                      </select>
                    </div>
                    <Button type="submit" className="w-full">Create</Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {projects.map((proj) => (
                  <Card key={proj.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <Folder className="h-5 w-5 text-muted-foreground" />
                          <span className="font-semibold">{proj.name}</span>
                        </div>
                        {proj.is_default && (
                          <Badge variant="secondary">Default</Badge>
                        )}
                      </div>
                      <div className="space-y-2 text-sm mb-4">
                        <p className="text-muted-foreground">{proj.description}</p>
                        <div className="flex items-center gap-2">
                          <Database className="h-3 w-3 text-muted-foreground" />
                          <Badge variant="outline">{proj.environment}</Badge>
                        </div>
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        className="w-full"
                        onClick={() => handleDelete('projects', proj.id)}
                        disabled={isDeleting === proj.id || proj.is_default}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {projects.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No projects found</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tags */}
        <TabsContent value="tags">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle>Tags</CardTitle>
                <CardDescription>Organize resources with tags</CardDescription>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    New Tag
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Tag</DialogTitle>
                    <DialogDescription>Create a new tag to organize your resources</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateTag} className="space-y-4">
                    <div className="space-y-2">
                      <Label>Tag Name</Label>
                      <Input
                        placeholder="production"
                        value={newTag.name}
                        onChange={(e) => setNewTag({ ...newTag, name: e.target.value })}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full">Create</Button>
                  </form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {tags.map((tag) => (
                  <Card key={tag.name}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-3">
                            <TagIcon className="h-4 w-4 text-muted-foreground" />
                            <span className="font-semibold">{tag.name}</span>
                          </div>
                          <div className="space-y-1 text-sm">
                            <div className="flex justify-between text-muted-foreground">
                              <span>Droplets:</span>
                              <span>{tag.resources_count.droplets}</span>
                            </div>
                            <div className="flex justify-between text-muted-foreground">
                              <span>Volumes:</span>
                              <span>{tag.resources_count.volumes}</span>
                            </div>
                            <div className="flex justify-between text-muted-foreground">
                              <span>Databases:</span>
                              <span>{tag.resources_count.databases}</span>
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete('tags', tag.name, tag.name)}
                          disabled={isDeleting === tag.name}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {tags.length === 0 && (
                <p className="text-center text-muted-foreground py-8">No tags found</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { Server, Plus, Power, RefreshCw, Trash2, HardDrive, Cpu, MemoryStick, Globe, Calendar, Shield } from 'lucide-react';
import type { Droplet, Region, Size, Image } from '@/types/digitalocean';

interface DropletsPanelProps {
  apiKey: string;
}

export function DropletsPanel({ apiKey }: DropletsPanelProps) {
  const [droplets, setDroplets] = useState<Droplet[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [sizes, setSizes] = useState<Size[]>([]);
  const [images, setImages] = useState<Image[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const [isActionLoading, setIsActionLoading] = useState<number | null>(null);

  // Create droplet form state
  const [newDroplet, setNewDroplet] = useState({
    name: '',
    region: '',
    size: '',
    image: '',
  });

  const fetchDroplets = async () => {
    try {
      const response = await fetch('/api/digitalocean/droplets', {
        headers: { 'x-api-key': apiKey }
      });
      const data = await response.json();
      setDroplets(data.droplets || []);
    } catch (error) {
      toast.error('Failed to fetch droplets');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchRegions = async () => {
    try {
      const response = await fetch('/api/digitalocean/regions', {
        headers: { 'x-api-key': apiKey }
      });
      const data = await response.json();
      setRegions(data.regions || []);
    } catch (error) {
      console.error('Failed to fetch regions');
    }
  };

  const fetchSizes = async () => {
    try {
      const response = await fetch('/api/digitalocean/sizes', {
        headers: { 'x-api-key': apiKey }
      });
      const data = await response.json();
      setSizes(data.sizes || []);
    } catch (error) {
      console.error('Failed to fetch sizes');
    }
  };

  const fetchImages = async () => {
    try {
      const response = await fetch('/api/digitalocean/images', {
        headers: { 'x-api-key': apiKey }
      });
      const data = await response.json();
      setImages(data.images || []);
    } catch (error) {
      console.error('Failed to fetch images');
    }
  };

  useEffect(() => {
    fetchDroplets();
    fetchRegions();
    fetchSizes();
    fetchImages();
  }, [apiKey]);

  const handleAction = async (dropletId: number, action: string) => {
    setIsActionLoading(dropletId);
    try {
      const response = await fetch(`/api/digitalocean/droplets/actions?action=${action}&id=${dropletId}`, {
        method: 'POST',
        headers: { 'x-api-key': apiKey },
        body: JSON.stringify({}),
      });

      if (!response.ok) throw new Error('Action failed');
      toast.success(`${action} action initiated`);
      setTimeout(fetchDroplets, 2000);
    } catch (error) {
      toast.error(`Failed to ${action}`);
    } finally {
      setIsActionLoading(null);
    }
  };

  const handleDelete = async (dropletId: number) => {
    if (!confirm('Are you sure you want to delete this droplet?')) return;

    setIsActionLoading(dropletId);
    try {
      const response = await fetch(`/api/digitalocean/droplets?id=${dropletId}`, {
        method: 'DELETE',
        headers: { 'x-api-key': apiKey },
      });

      if (!response.ok) throw new Error('Delete failed');
      toast.success('Droplet deleted successfully');
      fetchDroplets();
    } catch (error) {
      toast.error('Failed to delete droplet');
    } finally {
      setIsActionLoading(null);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreating(true);
    try {
      const response = await fetch('/api/digitalocean/droplets', {
        method: 'POST',
        headers: { 'x-api-key': apiKey },
        body: JSON.stringify(newDroplet),
      });

      if (!response.ok) throw new Error('Create failed');
      toast.success('Droplet creation initiated');
      setNewDroplet({ name: '', region: '', size: '', image: '' });
      setTimeout(fetchDroplets, 3000);
    } catch (error) {
      toast.error('Failed to create droplet');
    } finally {
      setIsCreating(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'default';
      case 'off': return 'secondary';
      case 'new': return 'outline';
      case 'archive': return 'destructive';
      default: return 'secondary';
    }
  };

  const getPublicIP = (droplet: Droplet) => {
    const v4 = droplet.networks.v4.find(n => n.type === 'public');
    return v4 ? v4.ip_address : 'N/A';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-pulse text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Server className="h-6 w-6" />
            Droplets
          </h2>
          <p className="text-muted-foreground">Manage your virtual machines</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={fetchDroplets}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Droplet
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Droplet</DialogTitle>
                <DialogDescription>
                  Configure and deploy a new DigitalOcean droplet
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    placeholder="my-droplet"
                    value={newDroplet.name}
                    onChange={(e) => setNewDroplet({ ...newDroplet, name: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="region">Region</Label>
                  <Select value={newDroplet.region} onValueChange={(v) => setNewDroplet({ ...newDroplet, region: v })} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select region" />
                    </SelectTrigger>
                    <SelectContent>
                      {regions.filter(r => r.available).map((r) => (
                        <SelectItem key={r.slug} value={r.slug}>
                          {r.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="size">Size</Label>
                  <Select value={newDroplet.size} onValueChange={(v) => setNewDroplet({ ...newDroplet, size: v })} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      {sizes.filter(s => s.available).map((s) => (
                        <SelectItem key={s.slug} value={s.slug}>
                          {s.slug} - ${s.price_monthly}/mo
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="image">Image</Label>
                  <Select value={newDroplet.image} onValueChange={(v) => setNewDroplet({ ...newDroplet, image: v })} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select image" />
                    </SelectTrigger>
                    <SelectContent>
                      {images.filter(i => i.public).slice(0, 20).map((i) => (
                        <SelectItem key={i.slug} value={i.slug!}>
                          {i.distribution} {i.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full" disabled={isCreating}>
                  {isCreating ? 'Creating...' : 'Create Droplet'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {droplets.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Server className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Droplets Found</h3>
            <p className="text-muted-foreground mb-4">Create your first droplet to get started</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>IP Address</TableHead>
                  <TableHead>Region</TableHead>
                  <TableHead>Size</TableHead>
                  <TableHead>Image</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {droplets.map((droplet) => (
                  <TableRow key={droplet.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Server className="h-4 w-4 text-muted-foreground" />
                        {droplet.name}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(droplet.status)}>
                        {droplet.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 text-sm">
                        <Globe className="h-3 w-3" />
                        {getPublicIP(droplet)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{droplet.region.slug}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1 text-sm">
                        <div className="flex items-center gap-1">
                          <Cpu className="h-3 w-3" />
                          {droplet.vcpus} vCPUs
                        </div>
                        <div className="flex items-center gap-1">
                          <MemoryStick className="h-3 w-3" />
                          {droplet.memory / 1024} GB RAM
                        </div>
                        <div className="flex items-center gap-1">
                          <HardDrive className="h-3 w-3" />
                          {droplet.disk} GB Disk
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div className="font-medium">{droplet.image.distribution}</div>
                        <div className="text-muted-foreground text-xs">{droplet.image.name}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        {new Date(droplet.created_at).toLocaleDateString()}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        {droplet.status === 'active' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleAction(droplet.id, 'reboot')}
                            disabled={isActionLoading === droplet.id}
                          >
                            <RefreshCw className="h-3 w-3" />
                          </Button>
                        )}
                        {droplet.status === 'active' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleAction(droplet.id, 'shutdown')}
                            disabled={isActionLoading === droplet.id}
                          >
                            <Power className="h-3 w-3" />
                          </Button>
                        )}
                        {droplet.status === 'off' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleAction(droplet.id, 'power_on')}
                            disabled={isActionLoading === droplet.id}
                          >
                            <Power className="h-3 w-3" />
                          </Button>
                        )}
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete(droplet.id)}
                          disabled={isActionLoading === droplet.id}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

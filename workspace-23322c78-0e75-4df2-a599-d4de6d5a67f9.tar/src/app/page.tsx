'use client';

import { useState, useEffect } from 'react';
import { useDigitalOceanApiKey } from '@/hooks/use-digitalocean-api-key';
import { ApiKeyInput } from '@/components/digitalocean/api-key-input';
import { DropletsPanel } from '@/components/digitalocean/droplets-panel';
import { OtherResourcesPanel } from '@/components/digitalocean/other-resources-panel';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Cloud, Server, Layers, LogOut, User } from 'lucide-react';
import { toast } from 'sonner';

export default function Home() {
  const { apiKey, removeApiKey, isLoaded, saveApiKey } = useDigitalOceanApiKey();
  const [activeView, setActiveView] = useState<'droplets' | 'other'>('droplets');
  const [accountInfo, setAccountInfo] = useState<any>(null);

  useEffect(() => {
    if (apiKey) {
      fetch('/api/digitalocean/account', {
        headers: { 'x-api-key': apiKey }
      })
        .then(res => res.json())
        .then(data => setAccountInfo(data.account))
        .catch(() => {
          toast.error('Failed to load account info');
        });
    }
  }, [apiKey]);

  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Cloud className="h-12 w-12 animate-pulse text-muted-foreground" />
      </div>
    );
  }

  if (!apiKey) {
    return <ApiKeyInput onSave={(key) => { saveApiKey(key); toast.success('API key saved successfully'); }} />;
  }


  const handleLogout = () => {
    removeApiKey();
    setAccountInfo(null);
    toast.success('Logged out successfully');
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Cloud className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold">DigitalOcean Manager</h1>
              <p className="text-xs text-muted-foreground">Complete Resource Management</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {accountInfo && (
              <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground">
                <span>{accountInfo.email}</span>
              </div>
            )}
            <Avatar className="h-8 w-8">
              <AvatarFallback>
                <User className="h-4 w-4" />
              </AvatarFallback>
            </Avatar>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur-sm sticky top-[73px] z-40">
        <div className="container mx-auto px-4">
          <div className="flex gap-1">
            <Button
              variant={activeView === 'droplets' ? 'default' : 'ghost'}
              onClick={() => setActiveView('droplets')}
              className="rounded-b-none"
            >
              <Server className="h-4 w-4 mr-2" />
              Droplets
            </Button>
            <Button
              variant={activeView === 'other' ? 'default' : 'ghost'}
              onClick={() => setActiveView('other')}
              className="rounded-b-none"
            >
              <Layers className="h-4 w-4 mr-2" />
              Other Resources
            </Button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6">
        {activeView === 'droplets' && <DropletsPanel apiKey={apiKey} />}
        {activeView === 'other' && <OtherResourcesPanel apiKey={apiKey} />}
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/50 mt-auto">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between text-sm text-muted-foreground">
          <p>DigitalOcean API Manager • All data is stored locally in your browser</p>
          <p>Built with Next.js 15 & shadcn/ui</p>
        </div>
      </footer>
    </div>
  );
}

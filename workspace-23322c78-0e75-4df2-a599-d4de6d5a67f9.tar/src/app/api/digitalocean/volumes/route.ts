import { NextRequest, NextResponse } from 'next/server';
import { fetchFromDigitalOcean } from '@/lib/digitalocean/fetch';

export async function GET(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const volumeId = searchParams.get('id');

    if (volumeId) {
      const data = await fetchFromDigitalOcean(`/volumes/${volumeId}`, apiKey);
      return NextResponse.json(data);
    }

    const data = await fetchFromDigitalOcean('/volumes', apiKey);
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to fetch volumes' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const body = await request.json();
    const data = await fetchFromDigitalOcean('/volumes', apiKey, {
      method: 'POST',
      body: JSON.stringify(body),
    });

    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to create volume' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const volumeId = searchParams.get('id');
    if (!volumeId) return NextResponse.json({ error: 'Volume ID is required' }, { status: 400 });

    await fetchFromDigitalOcean(`/volumes/${volumeId}`, apiKey, { method: 'DELETE' });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to delete volume' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { fetchFromDigitalOcean } from '@/lib/digitalocean/fetch';

export async function GET(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const imageId = searchParams.get('id');
    const slug = searchParams.get('slug');

    if (imageId) {
      const data = await fetchFromDigitalOcean(`/images/${imageId}`, apiKey);
      return NextResponse.json(data);
    }

    if (slug) {
      const data = await fetchFromDigitalOcean(`/images/${slug}`, apiKey);
      return NextResponse.json(data);
    }

    const data = await fetchFromDigitalOcean('/images', apiKey);
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Failed to fetch images' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const imageId = searchParams.get('id');
    if (!imageId) return NextResponse.json({ error: 'Image ID is required' }, { status: 400 });

    await fetchFromDigitalOcean(`/images/${imageId}`, apiKey, { method: 'DELETE' });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Failed to delete image' }, { status: 500 });
  }
}

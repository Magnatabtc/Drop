import { NextRequest, NextResponse } from 'next/server';
import { fetchFromDigitalOcean } from '@/lib/digitalocean/fetch';

export async function POST(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');

    if (!apiKey) {
      return NextResponse.json(
        { error: 'API key is required' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const dropletId = searchParams.get('id');
    const action = searchParams.get('action');

    if (!dropletId || !action) {
      return NextResponse.json(
        { error: 'Droplet ID and action are required' },
        { status: 400 }
      );
    }

    console.log('Droplet action:', action, 'Droplet ID:', dropletId);

    const body = await request.json();
    console.log('Request body:', body);

    // Some actions don't require a body, only send body if it has content
    const requestOptions: RequestInit = {
      method: 'POST',
    };

    if (Object.keys(body).length > 0) {
      requestOptions.body = JSON.stringify(body);
    }

    const data = await fetchFromDigitalOcean(
      `/droplets/${dropletId}/actions/${action}`,
      apiKey,
      requestOptions
    );

    console.log('Action response:', data);

    return NextResponse.json(data || { success: true });
  } catch (error) {
    console.error('Droplet action error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to perform droplet action' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');

    if (!apiKey) {
      return NextResponse.json(
        { error: 'API key is required' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const dropletId = searchParams.get('id');
    const actionId = searchParams.get('action_id');

    if (actionId && dropletId) {
      // Get specific action
      const data = await fetchFromDigitalOcean(
        `/droplets/${dropletId}/actions/${actionId}`,
        apiKey
      );
      return NextResponse.json(data || { success: true });
    }

    if (dropletId) {
      // List all actions for a droplet
      const data = await fetchFromDigitalOcean(
        `/droplets/${dropletId}/actions`,
        apiKey
      );
      return NextResponse.json(data || { success: true });
    }

    return NextResponse.json(
      { error: 'Droplet ID is required' },
      { status: 400 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to fetch droplet actions' },
      { status: 500 }
    );
  }
}

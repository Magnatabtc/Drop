import { NextRequest, NextResponse } from 'next/server';
import { fetchFromDigitalOcean } from '@/lib/digitalocean/fetch';

export async function GET(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');

    if (!apiKey) {
      return NextResponse.json(
        { error: 'API key is required' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const dropletId = searchParams.get('id');

    if (dropletId) {
      // Get single droplet
      const data = await fetchFromDigitalOcean(`/droplets/${dropletId}`, apiKey);
      return NextResponse.json(data || { success: true });
    }

    // List all droplets
    const data = await fetchFromDigitalOcean('/droplets', apiKey);
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to fetch droplets' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');

    if (!apiKey) {
      return NextResponse.json(
        { error: 'API key is required' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const data = await fetchFromDigitalOcean('/droplets', apiKey, {
      method: 'POST',
      body: JSON.stringify(body),
    });

    return NextResponse.json(data || { success: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to create droplet' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');

    if (!apiKey) {
      return NextResponse.json(
        { error: 'API key is required' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const dropletId = searchParams.get('id');

    if (!dropletId) {
      return NextResponse.json(
        { error: 'Droplet ID is required' },
        { status: 400 }
      );
    }

    await fetchFromDigitalOcean(`/droplets/${dropletId}`, apiKey, {
      method: 'DELETE',
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to delete droplet' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { fetchFromDigitalOcean } from '@/lib/digitalocean/fetch';

export async function GET(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('id');
    if (projectId) {
      const data = await fetchFromDigitalOcean(`/projects/${projectId}`, apiKey);
      return NextResponse.json(data);
    }

    const data = await fetchFromDigitalOcean('/projects', apiKey);
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Failed to fetch projects' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const body = await request.json();
    const data = await fetchFromDigitalOcean('/projects', apiKey, { method: 'POST', body: JSON.stringify(body) });
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Failed to create project' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('id');
    if (!projectId) return NextResponse.json({ error: 'Project ID is required' }, { status: 400 });

    await fetchFromDigitalOcean(`/projects/${projectId}`, apiKey, { method: 'DELETE' });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Failed to delete project' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    message: 'DigitalOcean API Gateway',
    endpoints: {
      account: '/api/digitalocean/account',
      droplets: '/api/digitalocean/droplets',
      volumes: '/api/digitalocean/volumes',
      loadBalancers: '/api/digitalocean/load-balancers',
      domains: '/api/digitalocean/domains',
      floatingIps: '/api/digitalocean/floating-ips',
      firewalls: '/api/digitalocean/firewalls',
      sshKeys: '/api/digitalocean/ssh-keys',
      snapshots: '/api/digitalocean/snapshots',
      images: '/api/digitalocean/images',
      regions: '/api/digitalocean/regions',
      sizes: '/api/digitalocean/sizes',
      projects: '/api/digitalocean/projects',
      tags: '/api/digitalocean/tags',
    }
  });
}

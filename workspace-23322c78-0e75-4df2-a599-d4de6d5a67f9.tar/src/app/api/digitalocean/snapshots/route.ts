import { NextRequest, NextResponse } from 'next/server';
import { fetchFromDigitalOcean } from '@/lib/digitalocean/fetch';

export async function GET(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const snapshotId = searchParams.get('id');
    if (snapshotId) {
      const data = await fetchFromDigitalOcean(`/snapshots/${snapshotId}`, apiKey);
      return NextResponse.json(data);
    }

    const data = await fetchFromDigitalOcean('/snapshots', apiKey);
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Failed to fetch snapshots' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const snapshotId = searchParams.get('id');
    if (!snapshotId) return NextResponse.json({ error: 'Snapshot ID is required' }, { status: 400 });

    await fetchFromDigitalOcean(`/snapshots/${snapshotId}`, apiKey, { method: 'DELETE' });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Failed to delete snapshot' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { fetchFromDigitalOcean } from '@/lib/digitalocean/fetch';

export async function GET(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const firewallId = searchParams.get('id');

    if (firewallId) {
      const data = await fetchFromDigitalOcean(`/firewalls/${firewallId}`, apiKey);
      return NextResponse.json(data);
    }

    const data = await fetchFromDigitalOcean('/firewalls', apiKey);
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to fetch firewalls' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const body = await request.json();
    const data = await fetchFromDigitalOcean('/firewalls', apiKey, {
      method: 'POST',
      body: JSON.stringify(body),
    });

    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to create firewall' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const apiKey = request.headers.get('x-api-key');
    if (!apiKey) return NextResponse.json({ error: 'API key is required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const firewallId = searchParams.get('id');
    if (!firewallId) return NextResponse.json({ error: 'Firewall ID is required' }, { status: 400 });

    await fetchFromDigitalOcean(`/firewalls/${firewallId}`, apiKey, { method: 'DELETE' });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to delete firewall' },
      { status: 500 }
    );
  }
}

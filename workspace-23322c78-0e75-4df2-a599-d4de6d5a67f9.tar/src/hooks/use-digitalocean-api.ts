'use client';

import { useState, useCallback } from 'react';
import type { Droplet, Volume, LoadBalancer, Domain, FloatingIP, Firewall, SSHKey, Snapshot, Image, Region, Size, Project, Tag, DigitalOceanAccount } from '@/types/digitalocean';

export function useDigitalOceanApi(apiKey: string | null) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const request = useCallback(async (
    endpoint: string,
    options?: RequestInit
  ): Promise<any> => {
    if (!apiKey) {
      throw new Error('API key is required');
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/digitalocean${endpoint}`, {
        ...options,
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json',
          ...options?.headers,
        },
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: response.statusText }));
        throw new Error(errorData.error || `HTTP ${response.status}`);
      }

      return await response.json();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'An error occurred';
      setError(message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [apiKey]);

  // Account
  const getAccount = useCallback(() => request('/account'), [request]);

  // Droplets
  const getDroplets = useCallback(() => request('/droplets'), [request]);
  const getDroplet = useCallback((id: number) => request(`/droplets?id=${id}`), [request]);
  const createDroplet = useCallback((data: any) => request('/droplets', {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);
  const deleteDroplet = useCallback((id: number) => request(`/droplets?id=${id}`, {
    method: 'DELETE',
  }), [request]);
  const rebootDroplet = useCallback((id: number) => request(`/droplets/actions?id=${id}&action=reboot`, {
    method: 'POST',
  }), [request]);
  const powerOnDroplet = useCallback((id: number) => request(`/droplets/actions?id=${id}&action=power_on`, {
    method: 'POST',
  }), [request]);
  const powerOffDroplet = useCallback((id: number) => request(`/droplets/actions?id=${id}&action=power_off`, {
    method: 'POST',
  }), [request]);
  const shutdownDroplet = useCallback((id: number) => request(`/droplets/actions?id=${id}&action=shutdown`, {
    method: 'POST',
  }), [request]);
  const resizeDroplet = useCallback((id: number, size: string, disk: boolean = false) => request(`/droplets/actions?id=${id}&action=resize`, {
    method: 'POST',
    body: JSON.stringify({ size, disk }),
  }), [request]);
  const snapshotDroplet = useCallback((id: number, name: string) => request(`/droplets/actions?id=${id}&action=snapshot`, {
    method: 'POST',
    body: JSON.stringify({ name }),
  }), [request]);

  // Volumes
  const getVolumes = useCallback(() => request('/volumes'), [request]);
  const getVolume = useCallback((id: string) => request(`/volumes?id=${id}`), [request]);
  const createVolume = useCallback((data: any) => request('/volumes', {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);
  const deleteVolume = useCallback((id: string) => request(`/volumes?id=${id}`, {
    method: 'DELETE',
  }), [request]);

  // Load Balancers
  const getLoadBalancers = useCallback(() => request('/load-balancers'), [request]);
  const getLoadBalancer = useCallback((id: string) => request(`/load-balancers?id=${id}`), [request]);
  const createLoadBalancer = useCallback((data: any) => request('/load-balancers', {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);
  const deleteLoadBalancer = useCallback((id: string) => request(`/load-balancers?id=${id}`, {
    method: 'DELETE',
  }), [request]);

  // Domains
  const getDomains = useCallback(() => request('/domains'), [request]);
  const getDomain = useCallback((name: string) => request(`/domains?name=${name}`), [request]);
  const createDomain = useCallback((data: any) => request('/domains', {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);
  const deleteDomain = useCallback((name: string) => request(`/domains?name=${name}`, {
    method: 'DELETE',
  }), [request]);

  // Floating IPs
  const getFloatingIPs = useCallback(() => request('/floating-ips'), [request]);
  const getFloatingIP = useCallback((ip: string) => request(`/floating-ips?ip=${ip}`), [request]);
  const createFloatingIP = useCallback((data: any) => request('/floating-ips', {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);
  const deleteFloatingIP = useCallback((ip: string) => request(`/floating-ips?ip=${ip}`, {
    method: 'DELETE',
  }), [request]);

  // Firewalls
  const getFirewalls = useCallback(() => request('/firewalls'), [request]);
  const getFirewall = useCallback((id: string) => request(`/firewalls?id=${id}`), [request]);
  const createFirewall = useCallback((data: any) => request('/firewalls', {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);
  const deleteFirewall = useCallback((id: string) => request(`/firewalls?id=${id}`, {
    method: 'DELETE',
  }), [request]);

  // SSH Keys
  const getSSHKeys = useCallback(() => request('/ssh-keys'), [request]);
  const getSSHKey = useCallback((id: number) => request(`/ssh-keys?id=${id}`), [request]);
  const createSSHKey = useCallback((data: any) => request('/ssh-keys', {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);
  const deleteSSHKey = useCallback((id: number) => request(`/ssh-keys?id=${id}`, {
    method: 'DELETE',
  }), [request]);

  // Snapshots
  const getSnapshots = useCallback(() => request('/snapshots'), [request]);
  const getSnapshot = useCallback((id: string) => request(`/snapshots?id=${id}`), [request]);
  const deleteSnapshot = useCallback((id: string) => request(`/snapshots?id=${id}`, {
    method: 'DELETE',
  }), [request]);

  // Images
  const getImages = useCallback(() => request('/images'), [request]);
  const getImage = useCallback((id: string) => request(`/images?id=${id}`), [request]);
  const getImageBySlug = useCallback((slug: string) => request(`/images?slug=${slug}`), [request]);
  const deleteImage = useCallback((id: string) => request(`/images?id=${id}`, {
    method: 'DELETE',
  }), [request]);

  // Regions
  const getRegions = useCallback(() => request('/regions'), [request]);

  // Sizes
  const getSizes = useCallback(() => request('/sizes'), [request]);

  // Projects
  const getProjects = useCallback(() => request('/projects'), [request]);
  const getProject = useCallback((id: string) => request(`/projects?id=${id}`), [request]);
  const createProject = useCallback((data: any) => request('/projects', {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);
  const deleteProject = useCallback((id: string) => request(`/projects?id=${id}`, {
    method: 'DELETE',
  }), [request]);

  // Tags
  const getTags = useCallback(() => request('/tags'), [request]);
  const createTag = useCallback((data: any) => request('/tags', {
    method: 'POST',
    body: JSON.stringify(data),
  }), [request]);
  const deleteTag = useCallback((name: string) => request(`/tags?name=${name}`, {
    method: 'DELETE',
  }), [request]);

  return {
    loading,
    error,
    request,
    // Account
    getAccount,
    // Droplets
    getDroplets,
    getDroplet,
    createDroplet,
    deleteDroplet,
    rebootDroplet,
    powerOnDroplet,
    powerOffDroplet,
    shutdownDroplet,
    resizeDroplet,
    snapshotDroplet,
    // Volumes
    getVolumes,
    getVolume,
    createVolume,
    deleteVolume,
    // Load Balancers
    getLoadBalancers,
    getLoadBalancer,
    createLoadBalancer,
    deleteLoadBalancer,
    // Domains
    getDomains,
    getDomain,
    createDomain,
    deleteDomain,
    // Floating IPs
    getFloatingIPs,
    getFloatingIP,
    createFloatingIP,
    deleteFloatingIP,
    // Firewalls
    getFirewalls,
    getFirewall,
    createFirewall,
    deleteFirewall,
    // SSH Keys
    getSSHKeys,
    getSSHKey,
    createSSHKey,
    deleteSSHKey,
    // Snapshots
    getSnapshots,
    getSnapshot,
    deleteSnapshot,
    // Images
    getImages,
    getImage,
    getImageBySlug,
    deleteImage,
    // Regions & Sizes
    getRegions,
    getSizes,
    // Projects
    getProjects,
    getProject,
    createProject,
    deleteProject,
    // Tags
    getTags,
    createTag,
    deleteTag,
  };
}

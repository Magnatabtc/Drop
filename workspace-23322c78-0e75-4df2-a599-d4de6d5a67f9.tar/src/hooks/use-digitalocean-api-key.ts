'use client';

import { useState, useEffect } from 'react';

const STORAGE_KEY = 'digitalocean_api_key';

export function useDigitalOceanApiKey() {
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Load API key on mount
    const stored = localStorage.getItem(STORAGE_KEY);
    setApiKey(stored);
    setIsLoaded(true);

    // Listen for storage changes (from other tabs/windows)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) {
        const newValue = localStorage.getItem(STORAGE_KEY);
        setApiKey(newValue);
      }
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const saveApiKey = (key: string) => {
    localStorage.setItem(STORAGE_KEY, key);
    setApiKey(key);
  };

  const removeApiKey = () => {
    localStorage.removeItem(STORAGE_KEY);
    setApiKey(null);
  };

  return { apiKey, saveApiKey, removeApiKey, isLoaded };
}

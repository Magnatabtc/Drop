export async function fetchFromDigitalOcean(
  endpoint: string,
  apiKey: string,
  options?: RequestInit
) {
  const response = await fetch(`https://api.digitalocean.com/v2${endpoint}`, {
    ...options,
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      ...options?.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: response.statusText }));
    throw new Error(error.message || `HTTP ${response.status}`);
  }

  // Handle empty responses (like 204 No Content from DELETE operations)
  const text = await response.text();

  if (!text || text.trim() === '') {
    return null;
  }

  try {
    return JSON.parse(text);
  } catch (error) {
    console.error('Failed to parse JSON response from', endpoint, ':', text);
    throw new Error('Invalid JSON response from API');
  }
}

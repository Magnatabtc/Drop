// DigitalOcean API v2 Types

export interface DigitalOceanAccount {
  droplet_limit: number;
  floating_ip_limit: number;
  volume_limit: number;
  email: string;
  email_verified: boolean;
  uuid: string;
  status: string;
  status_message: string;
}

export interface Region {
  name: string;
  slug: string;
  sizes: string[];
  features: string[];
  available: boolean;
}

export interface Size {
  slug: string;
  memory: number;
  vcpus: number;
  disk: number;
  transfer: number;
  price_monthly: number;
  price_hourly: number;
  available: boolean;
}

export interface Image {
  id: number;
  name: string;
  type: string;
  distribution: string;
  slug: string;
  public: boolean;
  regions: string[];
  created_at: string;
  min_disk_size: number;
}

export interface Network {
  v4: NetworkV4[];
  v6: NetworkV6[];
}

export interface NetworkV4 {
  ip_address: string;
  netmask: string;
  gateway: string;
  type: 'public' | 'private';
}

export interface NetworkV6 {
  ip_address: string;
  netmask: number;
  gateway: string;
  type: 'public' | 'private';
}

export interface Droplet {
  id: number;
  name: string;
  memory: number;
  vcpus: number;
  disk: number;
  locked: boolean;
  status: 'new' | 'active' | 'off' | 'archive';
  kernel: {
    id: number;
    name: string;
    version: string;
  };
  created_at: string;
  features: string[];
  backup_ids: number[];
  snapshot_ids: number[];
  image: Image;
  size: Size;
  size_slug: string;
  networks: Network;
  region: Region;
  tags: string[];
  volume_ids: string[];
}

export interface Volume {
  id: string;
  region: Region;
  droplet_ids: number[];
  name: string;
  description: string;
  size_gigabytes: number;
  filesystem_type: string;
  filesystem_label: string;
  created_at: string;
  tags: string[];
}

export interface LoadBalancer {
  id: string;
  name: string;
  ip: string;
  algorithm: string;
  status: string;
  created_at: string;
  updated_at: string;
  redirect_http_to_https: boolean;
  enable_proxy_protocol: boolean;
  enable_backend_keepalive: boolean;
  sticky_sessions: {
    type: string;
    cookie_name: string;
    cookie_ttl_seconds: number;
  };
  health_check: {
    protocol: string;
    port: number;
    path: string;
    check_interval_seconds: number;
    response_timeout_seconds: number;
    unhealthy_threshold: number;
    healthy_threshold: number;
  };
  forwarding_rules: ForwardingRule[];
  droplet_ids: number[];
  tag: string;
  region: Region;
  size: string;
  size_unit: number;
  http_idle_timeout_seconds: number;
  ssl: boolean;
}

export interface ForwardingRule {
  entry_protocol: string;
  entry_port: number;
  target_protocol: string;
  target_port: number;
  certificate_id: string;
  tls_passthrough: boolean;
}

export interface Domain {
  name: string;
  ttl: number;
  zone_file: string;
}

export interface DomainRecord {
  id: number;
  type: string;
  name: string;
  data: string;
  priority: number;
  port: number;
  ttl: number;
  weight: number;
  flags: number;
  tag: string;
}

export interface FloatingIP {
  ip: string;
  droplet: {
    id: number;
    name: string;
    created_at: string;
  } | null;
  region: Region;
  locked: boolean;
}

export interface Firewall {
  id: string;
  name: string;
  status: string;
  inbound_rules: FirewallRule[];
  outbound_rules: FirewallRule[];
  created_at: string;
  droplet_ids: number[];
  tags: string[];
  pending_changes: {
    droplet_id: number;
    removing: boolean;
    status: string;
  }[];
}

export interface FirewallRule {
  protocol: string;
  ports: string;
  sources: {
    addresses: string[];
    tags: string[];
    droplet_ids: number[];
    load_balancer_uids: string[];
  };
}

export interface SSHKey {
  id: number;
  name: string;
  public_key: string;
  fingerprints: string[];
}

export interface Snapshot {
  id: string;
  name: string;
  resource_type: 'droplet' | 'volume';
  resource_id: number;
  regions: string[];
  min_disk_size: number;
  size_gigabytes: number;
  created_at: string;
}

export interface Project {
  id: string;
  owner_id: number;
  owner_uuid: string;
  name: string;
  description: string;
  purpose: string;
  environment: 'Development' | 'Staging' | 'Production';
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export interface Tag {
  name: string;
  resources_count: {
    droplets: number;
    volumes: number;
    volume_snapshots: number;
    databases: number;
    load_balancers: number;
  };
}

// Action types
export interface Action {
  id: number;
  status: 'in-progress' | 'completed' | 'errored';
  type: string;
  started_at: string;
  completed_at: string | null;
  resource_id: number;
  resource_type: string;
  region: Region;
}

// API Response Types
export interface DigitalOceanListResponse<T> {
  [key: string]: T[];
  meta: {
    total: number;
  };
  links: {
    pages: {
      first?: string;
      prev?: string;
      next?: string;
      last?: string;
    };
  };
}

export interface DigitalOceanResponse<T> {
  [key: string]: T;
}

// Create Droplet Request
export interface CreateDropletRequest {
  name: string;
  region: string;
  size: string;
  image: string;
  ssh_keys?: number[];
  backups?: boolean;
  ipv6?: boolean;
  private_networking?: boolean;
  user_data?: string;
  monitoring?: boolean;
  tags?: string[];
  volumes?: string[];
}

// Create Volume Request
export interface CreateVolumeRequest {
  size_gigabytes: number;
  name: string;
  description?: string;
  region: string;
  filesystem_type?: string;
  filesystem_label?: string;
  tags?: string[];
}

// Create Domain Request
export interface CreateDomainRequest {
  name: string;
  ip_address?: string;
}

// Create Firewall Request
export interface CreateFirewallRequest {
  name: string;
  inbound_rules: FirewallRule[];
  outbound_rules: FirewallRule[];
  droplet_ids?: number[];
  tags?: string[];
}

// Create Load Balancer Request
export interface CreateLoadBalancerRequest {
  name: string;
  region: string;
  droplet_ids?: number[];
  tag?: string;
  forwarding_rules: ForwardingRule[];
  health_check?: LoadBalancer['health_check'];
  sticky_sessions?: LoadBalancer['sticky_sessions'];
  redirect_http_to_https?: boolean;
  enable_proxy_protocol?: boolean;
  enable_backend_keepalive?: boolean;
}

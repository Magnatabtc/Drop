# DigitalOcean Manager

Um painel completo de gerenciamento para a DigitalOcean API v2. Este aplicativo permite que você gerencie todos os seus recursos da DigitalOcean a partir de uma única interface.

## Funcionalidades

### Gerenciamento de Droplets
- Listar todos os droplets com informações detalhadas
- Criar novos droplets com configuração completa
- Ver detalhes completos de cada droplet (overview, networking, features, actions)
- Ações rápidas: Reboot, Power On, Power Off, Shutdown
- Criar snapshots de droplets
- Redimensionar droplets
- Excluir droplets com confirmação
- Visualizar status, IP público, região, imagem e tamanho

### Outros Recursos
Gerencie todos os seus recursos da DigitalOcean:

1. **Volumes** - Armazenamento em bloco de rede
2. **Load Balancers** - Balanceadores de carga distribuídos
3. **Domínios** - Gerencie seus domínios e DNS
4. **Floating IPs** - Endereços IP públicos reatribuíveis
5. **Firewalls** - Controle o tráfego de entrada e saída
6. **SSH Keys** - Chaves públicas para autenticação SSH
7. **Snapshots** - Imagens point-in-time de droplets e volumes
8. **Imagens** - Distribuições de sistemas operacionais e imagens personalizadas
9. **Projetos** - Organize seus recursos da DigitalOcean
10. **Tags** - Organize e agrupe seus recursos

## Arquitetura

### Frontend
- **Next.js 15** com App Router
- **TypeScript** para type safety
- **shadcn/ui** componentes para UI moderna
- **Tailwind CSS 4** para estilização
- **Lucide React** para ícones
- **Sonner** para notificações toast
- **React Hooks** para gerenciamento de estado

### Backend
- **Next.js API Routes** para comunicação com DigitalOcean
- Toda a comunicação com a API da DigitalOcean é feita no backend
- Autenticação via Personal Access Token (API Key)

### Segurança
- API Key armazenada apenas no localStorage do navegador
- Nenhum dado sensível é enviado para servidores externos
- Comunicação direta com a API da DigitalOcean

## Como Usar

### 1. Obtenha uma API Key da DigitalOcean
1. Faça login na sua conta DigitalOcean
2. Vá para Settings → API → Tokens/Keys
3. Clique em "Generate New Token"
4. Dê um nome ao token (ex: "DigitalOcean Manager")
5. Selecione os escopos desejados (Recomendado: Read + Write)
6. Clique em "Generate Token"
7. Copie o token gerado

### 2. Faça Login
1. Abra o aplicativo
2. Insira sua API Key no campo de autenticação
3. Clique em "Connect to DigitalOcean"
4. A API Key será salva no localStorage do navegador

### 3. Gerencie seus Recursos
- Use a navegação para alternar entre Droplets e Outros Recursos
- No painel de Droplets, visualize e gerencie suas máquinas virtuais
- No painel de Outros Recursos, acesse volumes, load balancers, domínios, etc.

## Endpoints da API Implementados

### Droplets
- `GET /api/digitalocean/droplets` - Listar droplets
- `GET /api/digitalocean/droplets?id={id}` - Obter droplet específico
- `POST /api/digitalocean/droplets` - Criar droplet
- `DELETE /api/digitalocean/droplets?id={id}` - Excluir droplet

### Ações de Droplet
- `POST /api/digitalocean/droplets/actions?id={id}&action={action}` - Executar ação

### Outros Recursos
- `GET /api/digitalocean/volumes` - Listar volumes
- `POST /api/digitalocean/volumes` - Criar volume
- `DELETE /api/digitalocean/volumes?id={id}` - Excluir volume

- `GET /api/digitalocean/load-balancers` - Listar load balancers
- `POST /api/digitalocean/load-balancers` - Criar load balancer
- `DELETE /api/digitalocean/load-balancers?id={id}` - Excluir load balancer

- `GET /api/digitalocean/domains` - Listar domínios
- `POST /api/digitalocean/domains` - Criar domínio
- `DELETE /api/digitalocean/domains?name={name}` - Excluir domínio

- `GET /api/digitalocean/floating-ips` - Listar floating IPs
- `POST /api/digitalocean/floating-ips` - Criar floating IP
- `DELETE /api/digitalocean/floating-ips?ip={ip}` - Excluir floating IP

- `GET /api/digitalocean/firewalls` - Listar firewalls
- `POST /api/digitalocean/firewalls` - Criar firewall
- `DELETE /api/digitalocean/firewalls?id={id}` - Excluir firewall

- `GET /api/digitalocean/ssh-keys` - Listar SSH keys
- `POST /api/digitalocean/ssh-keys` - Criar SSH key
- `DELETE /api/digitalocean/ssh-keys?id={id}` - Excluir SSH key

- `GET /api/digitalocean/snapshots` - Listar snapshots
- `DELETE /api/digitalocean/snapshots?id={id}` - Excluir snapshot

- `GET /api/digitalocean/images` - Listar imagens
- `DELETE /api/digitalocean/images?id={id}` - Excluir imagem

- `GET /api/digitalocean/regions` - Listar regiões
- `GET /api/digitalocean/sizes` - Listar tamanhos disponíveis

- `GET /api/digitalocean/projects` - Listar projetos
- `POST /api/digitalocean/projects` - Criar projeto
- `DELETE /api/digitalocean/projects?id={id}` - Excluir projeto

- `GET /api/digitalocean/tags` - Listar tags
- `POST /api/digitalocean/tags` - Criar tag
- `DELETE /api/digitalocean/tags?name={name}` - Excluir tag

- `GET /api/digitalocean/account` - Obter informações da conta

## Componentes

### Hooks Personalizados
- `useDigitalOceanApiKey` - Gerencia a API Key no localStorage
- `useDigitalOceanApi` - Fornece métodos para interagir com a API

### Componentes Principais
- `ApiKeyInput` - Formulário de autenticação
- `DropletsPanel` - Painel principal de gerenciamento de droplets
- `OtherResourcesPanel` - Painel para gerenciar outros recursos

## Tecnologias Utilizadas

- **Frontend**: Next.js 15, React 19, TypeScript 5
- **UI Library**: shadcn/ui, Radix UI
- **Styling**: Tailwind CSS 4
- **Icons**: Lucide React
- **Notifications**: Sonner
- **API**: DigitalOcean API v2

## Desenvolvimento

### Instalação
```bash
bun install
```

### Executar servidor de desenvolvimento
```bash
bun run dev
```

### Lint
```bash
bun run lint
```

### Build
```bash
bun run build
```

## Notas Importantes

- A API Key é armazenada apenas no localStorage do navegador
- Não há persistência em banco de dados
- Todas as requisições são feitas diretamente para a API da DigitalOcean
- Certifique-se de que sua API Key tem os escopos necessários para as operações que deseja realizar

## Licença

Este projeto foi desenvolvido para fins educacionais e de gerenciamento pessoal de recursos da DigitalOcean.
